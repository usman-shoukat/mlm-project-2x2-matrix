<?php $__env->startSection('title', ' | Add Member'); ?>



<?php $__env->startSection('content'); ?>
    <div class="main-grid">
        <div class="row">
            <div class="col-md-12">
                <?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo e(\Illuminate\Support\Facades\Session::get('message')); ?></div>
                <?php endif; ?>
            </div>
            <div class="col-md-12">
                <?php if(\Illuminate\Support\Facades\Session::has('error')): ?>
                    <div class="alert alert-danger"><?php echo e(\Illuminate\Support\Facades\Session::get('message')); ?></div>
                <?php endif; ?>
            </div>

            <form  method="get" action="<?php echo e(route('sreach')); ?>">

                <?php echo e(csrf_field()); ?>


                <input type="text" name="search" value="">
                <button type="submit" class="btn btn-default w3ls-button" style="width: 20%;">Submit</button>
            </form>





            <br><br><br>






            <br><br><br>
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Add balances</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <th scope="row"> <?php echo e($user->id); ?></th>
                    <td>   <?php echo e($user->name); ?></td>
                    <td> <?php echo e($user->email); ?></td>
                    <td> <?php echo e($user->mobile); ?></td>
                    <td>  <form  method="post" action="<?php echo e(url('/add', [$user->id])); ?>">

                            <?php echo e(csrf_field()); ?>


                            <input type="text" name="balance" value="<?php echo e($user->balance); ?>">
                            <button type="submit" class="btn btn-default w3ls-button" style="width: 20%;">Add balances</button>
                        </form></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        <?php echo e($users->links()); ?>

        <div class="row">
            <div class="col-md-6">

                <div class="form-group row">
                    <div class="col-md-12">
                        <?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
                            <div class="alert alert-success"><?php echo e(\Illuminate\Support\Facades\Session::get('message')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-12">
                        <?php if(\Illuminate\Support\Facades\Session::has('error')): ?>
                            <div class="alert alert-danger"><?php echo e(\Illuminate\Support\Facades\Session::get('message')); ?></div>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sites\future\resources\views/alluser.blade.php ENDPATH**/ ?>