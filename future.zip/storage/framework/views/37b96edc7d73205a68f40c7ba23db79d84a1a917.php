<?php $__env->startSection('title'); ?> | login <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sites\future\resources\views/auth/login.blade.php ENDPATH**/ ?>