<ul>
    <?php $__currentLoopData = $user->referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userReferral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo \App\Helpers\UserHelper::treeMemberLIHelper($userReferral->user); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH E:\sites\future\resources\views/partials/members-ul.blade.php ENDPATH**/ ?>