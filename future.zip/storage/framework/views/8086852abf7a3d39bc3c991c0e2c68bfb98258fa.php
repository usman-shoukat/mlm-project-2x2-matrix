<?php $__env->startSection('title', ' | Add Member'); ?>



<?php $__env->startSection('content'); ?>
    <div class="main-grid">
        <div class="row">
            <div class="col-md-12">
                <?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo e(\Illuminate\Support\Facades\Session::get('success')); ?></div>
                <?php endif; ?>
            </div>
            <div class="col-md-12">
                <?php if(\Illuminate\Support\Facades\Session::has('error')): ?>
                    <div class="alert alert-danger"><?php echo e(\Illuminate\Support\Facades\Session::get('error')); ?></div>
                <?php endif; ?>
            </div>

            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="card">

                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('changePassword')); ?>">
                                    <?php echo csrf_field(); ?>

                                    <div class="input-group mb-3">
                                      <label> <b>Old Password</b></label>
                                        <input type="password" name="oldpassword" class="form-control <?php echo e($errors->has('oldpassword') ? 'is-invalid' : ''); ?>"">
                                        <div class="input-group-append">
                                            <div class="input-group-text">

                                            </div>
                                        </div>
                                        <?php if($errors->has('oldpassword')): ?>
                                            <div class="invalid-feedback">
                                                <strong><?php echo e($errors->first('oldpassword')); ?></strong>
                                            </div>
                                        <?php endif; ?>
                                    </div>



                                    
                                    <div class="input-group mb-3">
                                        <label> <b>Password</b></label>
                                        <input type="password" name="password"
                                               class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>"
                                              ">
                                        <div class="input-group-append">
                                            <div class="input-group-text">

                                            </div>
                                        </div>
                                        <?php if($errors->has('password')): ?>
                                            <div class="invalid-feedback">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    
                                    <div class="input-group mb-3">
                                        <label> <b>Password Confirmation</b></label>
                                        <input type="password" name="password_confirmation"
                                               class="form-control <?php echo e($errors->has('password_confirmation') ? 'is-invalid' : ''); ?>"
                                               ">
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                            </div>
                                        </div>
                                        <?php if($errors->has('password_confirmation')): ?>
                                            <div class="invalid-feedback">
                                                <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                            </div>
                                        <?php endif; ?>
                                    </div>

<br>
                                    <div class="form-group row mb-0">
                                        <div class="col-md-8 offset-md-4">
                                            <button type="submit" class="btn btn-primary">
                                                Update Password
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">


            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>

        $(function () {
            // $('#create-user-form').validate();
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sites\future\resources\views/updatepass.blade.php ENDPATH**/ ?>