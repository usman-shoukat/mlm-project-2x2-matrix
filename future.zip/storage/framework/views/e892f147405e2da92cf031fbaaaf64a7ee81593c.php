<?php $__env->startSection('title', ' | Add Member'); ?>



<?php $__env->startSection('content'); ?>
    <div class="main-grid">
        <div class="row">
            <div class="col-md-12">
                <?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo e(\Illuminate\Support\Facades\Session::get('message')); ?></div>
                <?php endif; ?>
            </div>
            <div class="col-md-12">
                <?php if(\Illuminate\Support\Facades\Session::has('error')): ?>
                    <div class="alert alert-danger"><?php echo e(\Illuminate\Support\Facades\Session::get('message')); ?></div>
                <?php endif; ?>
            </div>
            <div class="col-md-12">
                <?php if($errors->any()): ?>

                    <ul class="form-error-list-on-top">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                <?php endif; ?>
            </div>
            <form name="randform">
                <input type="button" value="Genrate Token Code" onClick="randomString();">&nbsp;
                <input type="text" name="randomfield" value="">
            </form><br><br><br>
            <script language="javascript" type="text/javascript">
                function randomString() {
                    var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
                    var string_length = 8;
                    var randomstring = '';
                    for (var i=0; i<string_length; i++) {
                        var rnum = Math.floor(Math.random() * chars.length);
                        randomstring += chars.substring(rnum,rnum+1);
                    }
                    document.randform.randomfield.value = randomstring;
                }
            </script>

            <div class="col-md-6">
                <div class="panel panel-widget forms-panel">
                    <div class="forms">
                        <div class="form-grids widget-shadow" >
                            <div class="form-title">
                                <h4>Add User Token :</h4>
                            </div>
                            <div class="form-body">
                                <form method="post" action="<?php echo e(route('token.save')); ?>" enctype="multipart/form-data" >
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="token">User_Id</label>
                                        <input type="text" class="form-control" name="user_id"  placeholder="" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="token">Token</label>
                                        <input type="text" class="form-control" name="token"  placeholder="" required>
                                    </div>

                                    <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="text" class="form-control" name="name"  placeholder="" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email </label>
                                        <input type="email" class="form-control"  name="email" required>
                                    </div>


                                    <button type="submit" class="btn btn-default w3ls-button" style="width: 20%;">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">

                <div class="form-group row">
                    <div class="col-md-12">
                        <?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
                            <div class="alert alert-success"><?php echo e(\Illuminate\Support\Facades\Session::get('message')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-12">
                        <?php if(\Illuminate\Support\Facades\Session::has('error')): ?>
                            <div class="alert alert-danger"><?php echo e(\Illuminate\Support\Facades\Session::get('message')); ?></div>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sites\future\resources\views/addtoken.blade.php ENDPATH**/ ?>