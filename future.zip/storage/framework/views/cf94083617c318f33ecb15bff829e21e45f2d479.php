<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?> <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Scripts -->


    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!-- bootstrap-css -->
    <link rel="stylesheet" href="/css/bootstrap.css">
    <!-- //bootstrap-css -->
    <!-- Custom CSS -->
    <link href="/css/style.css" rel='stylesheet' type='text/css' />
    <!-- font CSS -->
    <link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <!-- font-awesome icons -->
    <link rel="stylesheet" href="/css/font.css" type="text/css"/>
    <link href="/css/font-awesome.css" rel="stylesheet">
    <!-- //font-awesome icons -->
    <script src="/js/jquery2.0.3.min.js"></script>
    <script src="/js/modernizr.js"></script>
    <script src="/js/jquery.cookie.js"></script>
    <script src="/js/screenfull.js"></script>
    <script>
        $(function () {
            $('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

            if (!screenfull.enabled) {
                return false;
            }



            $('#toggle').click(function () {
                screenfull.toggle($('#container')[0]);
            });
        });
    </script>
    <!-- charts -->
    <script src="/js/raphael-min.js"></script>
    <script src="/js/morris.js"></script>
    <link rel="stylesheet" href="/css/morris.css">
    <!-- //charts -->
    <!--skycons-icons-->
    <script src="/js/skycons.js"></script>
    <!--//skycons-icons-->

    <?php echo $__env->yieldContent('css'); ?>
</head>

<body class="dashboard-page">
<script>
    var theme = $.cookie('protonTheme') || 'default';
    $('body').removeClass (function (index, css) {
        return (css.match (/\btheme-\S+/g) || []).join(' ');
    });
    if (theme !== 'default') $('body').addClass(theme);
</script>

<nav class="main-menu">
    <ul>
        <li>
            <a href="/home">
                <i class="fa fa-home nav_icon"></i>
                <span class="nav-text">
					Dashboard
					</span>
            </a>
        </li>
        <li class="has-subnav">
            <a href="<?php echo e(route('upliner')); ?>">
                <i class="fa fa-cogs" aria-hidden="true"></i>
                <span class="nav-text">
					Upliner
				</span>

            </a>
        </li>
        <?php if(auth()->user()->is_admin  == 1): ?>
        <li class="has-subnav">
            <a href="<?php echo e(route('token.create')); ?>">
                <i class="fa fa-cogs" aria-hidden="true"></i>
                <span class="nav-text">
					Add User Token

				</span>

            </a>
        </li>
        <?php endif; ?>
        <?php if(auth()->user()->is_admin  == 1): ?>
            <li class="has-subnav">
                <a href="<?php echo e(route('all.user')); ?>">
                    <i class="fa fa-cogs" aria-hidden="true"></i>
                    <span class="nav-text">
					All Users

				</span>

                </a>
            </li>
        <?php endif; ?>


        <li class="has-subnav">
            <a href="<?php echo e(route('reward')); ?>">
                <i class="fa fa-file-text-o nav_icon"></i>
                <span class="nav-text">Rewards</span>

            </a>

        </li>
        <li>
            <a href="<?php echo e(route('wallet')); ?>">
                <i class="fa fa-bar-chart nav_icon"></i>
                <span class="nav-text">
						Wallet
					</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('user.create')); ?>">
                <i class="icon-font nav-icon"></i>
                <span class="nav-text">
					Add Members
					</span>
            </a>
        </li>
        <li>
            <a href="#">
                <i class="icon-table nav-icon"></i>
                <span class="nav-text">
					Contact Us
					</span>
            </a>
        </li>
        <li>
            <a href="/change-password">
                <i class="fa fa-cogs nav-icon"></i>
                <span class="nav-text">
					Setting
					</span>
            </a>
        </li>
        <li>
            <a href="/down" >
                <i class="fa fa-download nav-icon"></i>


                <span class="nav-text">
					Joining Form
					</span>
            </a>
        </li>

</nav>

<section class="wrapper scrollable">
    <nav class="user-menu">
        <a href="javascript:;" class="main-menu-access">
            <i class="icon-proton-logo"></i>
            <i class="icon-reorder"></i>
        </a>
    </nav>
    <section class="title-bar">
        <div class="logo">
            <h1><a href="/home"><img src="/images/logo.png" width="50px" height="50px" alt="" /></a></h1>
        </div>


        <div class="header-right">
            <div class="profile_details_left">
                <div class="header-right-left">
                    <!--notifications of menu start -->
                    <ul class="nofitications-dropdown">
                        <li class="dropdown head-dpdn">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-envelope"></i><span class="badge">0</span></a>
                            <ul class="dropdown-menu anti-dropdown-menu w3l-msg">
                                <li>
                                    <div class="notification_header">
                                        <h3>You have 0 new messages</h3>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="notification_bottom">
                                        <a href="#">See all messages</a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown head-dpdn">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-bell"></i><span class="badge blue">0</span></a>
                            <ul class="dropdown-menu anti-dropdown-menu agile-notification">
                                <li>
                                    <div class="notification_header">
                                        <h3>You have 0 new notifications</h3>
                                    </div>
                                </li>
                               
                                <li>
                                    <div class="notification_bottom">
                                        <a href="#">See all notifications</a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        
                        <div class="clearfix"> </div>
                    </ul>
                </div>
                <div class="profile_details">
                    <ul>
                        <li class="dropdown profile_details_drop">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                <div class="profile_img">
                                    <span class="prfil-img"><i class="fa fa-user" aria-hidden="true"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                            <ul class="dropdown-menu drp-mnu">


                                <li onclick="document.getElementById('logout-form').submit(); return false;"> <a href="#"><i class="fa fa-sign-out"></i> Logout</a> </li>
                                <form method="post" action="<?php echo e(url('logout')); ?>" id="logout-form"> <?php echo csrf_field(); ?> </form>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
        <div class="clearfix"> </div>
    </section>
    <?php echo $__env->yieldContent('content'); ?>;
    <div class="clearfix"> </div>
    </div>
    </div>
    <div class="clearfix"> </div>
    </div>
    </div>
    <!-- footer -->
    <div class="footer">
        <p>© 2020 Xhine Way . All Rights Reserved .  <a href="http://w3layouts.com/"></a></p>
    </div>
    <!-- //footer -->
</section>

<script src="/js/bootstrap.js"></script>
<script src="/js/proton.js"></script>
<?php echo $__env->yieldContent('js'); ?>
</body>
</html>
<?php /**PATH E:\sites\future\resources\views/layouts/app.blade.php ENDPATH**/ ?>