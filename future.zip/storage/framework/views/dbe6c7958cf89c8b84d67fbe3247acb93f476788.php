<li><a href="#"><img src="<?php echo e(asset('\images\avatar.png')); ?>" style=" vertical-align: middle; width: 50px; height: 50px;border-radius: 50%;"><br>
        <?php echo e($user->name); ?>

    </a>
    <?php if($user->referrals->count() > 0): ?>
        <?php echo \App\Helpers\UserHelper::treeMemberULHelper($user); ?>

    <?php endif; ?>
</li>
<?php /**PATH E:\sites\future\resources\views/partials/members-li.blade.php ENDPATH**/ ?>