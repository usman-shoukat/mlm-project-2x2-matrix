<?php $__env->startSection('title', ' | Upliner'); ?>


<style>

    $border-width: 1px;
    $reverse: true;

    .tree {
    <?php if: ?> $reverse {
             transform: rotate(180deg);
             transform-origin: 50%;
         }
    }

    .tree ul {
        position: relative;
        padding: 1em 0;
        white-space: nowrap;
        margin: 0 auto;
        text-align: center;
    &::after {
         content: '';
         display: table;
         clear: both;
     }
    }

    .tree li {
        display: inline-block; // need white-space fix
    vertical-align: top;
        text-align: center;
        list-style-type: none;
        position: relative;
        padding: 1em .5em 0 .5em;
    &::before,
    &::after {
         content: '';
         position: absolute;
         top: 0;
         right: 50%;
         border-top: $border-width solid #ccc;
         width: 50%;
         height: 1em;
     }
    &::after {
         right: auto;
         left: 50%;
         border-left: $border-width solid #ccc;
     }
    &:only-child::after,
    &:only-child::before {
         display: none;
     }
    &:only-child {
         padding-top: 0;
     }
    &:first-child::before,
    &:last-child::after {
         border: 0 none;
     }
    &:last-child::before{
         border-right: $border-width solid #ccc;
         border-radius: 0 5px 0 0;
     }
    &:first-child::after{
         border-radius: 5px 0 0 0;
     }
    }

    .tree ul ul::before{
        content: '';
        position: absolute;
        top: 0;
        left: 50%;
        border-left: $border-width solid #ccc;
        width: 0;
        height: 1em;
    }

    .tree li a {
        border: $border-width solid #ccc;
        padding: .5em .75em;
        text-decoration: none;
        display: inline-block;
        border-radius: 5px;
        color: #333;
        position: relative;
        top: $border-width;
    <?php if: ?> $reverse {
             transform: rotate(180deg);
         }
    }

    .tree li a:hover,
    .tree li a:hover+ul li a {
        background: #e9453f;
        color: #fff;
        border: $border-width solid #e9453f;
    }

    .tree li a:hover + ul li::after,
    .tree li a:hover + ul li::before,
    .tree li a:hover + ul::before,
    .tree li a:hover + ul ul::before{
        border-color:  #e9453f;
    }
</style>
<?php $__env->startSection('content'); ?>
    <div class="main-grid">
        <div class="row">
            <div class="col-md-12">
                <br />
                <br />
            </div>



                <div class="container-fluid" >
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="tree" >

                        <ul>
                            <li>
 <a href="#"><img src="<?php echo e(asset('\images\avatar.png')); ?>" style=" vertical-align: middle; width: 50px; height: 50px;border-radius: 50%;"><br><strong> (<?php echo e(auth()->user()->email); ?>)</strong></a>
                                <?php if(auth()->user()->referrals->count() > 0): ?>
                                    <?php echo \App\Helpers\UserHelper::treeMemberULHelper(auth()->user()); ?>

                                <?php else: ?>
                                    <ul>
                                        <li><a href="#">You have not added any member</a></li>
                                    </ul>
                                <?php endif; ?>
                            </li>
                        </ul>

                    </div>
                </div>

            </div>

        </div>
        <div class="tree">
            <ul>
                <li>
                    <a href="#">Parent</a>
                    <ul>
                        <li>
                            <a href="#">Child</a>
                            <ul>
                                <li>
                                    <a href="#">Grand Child</a>
                                </li><li>
                                    <a href="#">Grand Child</a>
                                    <ul>
                                        <li>
                                            <a href="#">Grand Child</a>
                                        </li><li>
                                            <a href="#">Grand Child</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li><li>
                            <a href="#">Child</a>
                            <ul>
                                <li>
                                    <a href="#">Grand Child</a>
                                    <ul>
                                        <li>
                                            <a href="#">Grand Grand Child</a>
                                        </li>
                                    </ul>
                                </li><li>
                                    <a href="#">Grand Child</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
            </ul>

        <div class="row">
            <div class="col-md-12">
                <br />
                <br />
                <br />
                <br />
                <br />
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>

        $(function () {
            // $('#create-user-form').validate();
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sites\future\resources\views/upliner.blade.php ENDPATH**/ ?>