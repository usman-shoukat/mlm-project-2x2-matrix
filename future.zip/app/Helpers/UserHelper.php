<?php


namespace App\Helpers;


class UserHelper
{

    public static function treeMemberULHelper($user)
    {
        return view('partials.members-ul',['user'=>$user])->render();
    }
    public static function treeMemberLIHelper($user)
    {
        return view('partials.members-li',['user'=>$user])->render();
    }
}
