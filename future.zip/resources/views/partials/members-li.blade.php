<li><a href="#"><img src="{{ asset('\images\avatar.png')}}" style=" vertical-align: middle; width: 50px; height: 50px;border-radius: 50%;"><br>
        {{ $user->name }}
    </a>
    @if($user->referrals->count() > 0)
        {!! \App\Helpers\UserHelper::treeMemberULHelper($user) !!}
    @endif
</li>
