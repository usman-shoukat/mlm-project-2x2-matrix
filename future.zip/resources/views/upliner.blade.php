@extends('layouts.app')

@section('title', ' | Upliner')



@section('content')
    <div class="main-grid">
        <div class="row">
            <div class="col-md-12">
                <br />
                <br />
            </div>

            <div class="col-md-4"></div>
            <div class="col-md-12">

                <div class="tree-view-container" >
                    <div class="tree" >

                        <ul>
                            <li>
 <a href="#"><img src="{{ asset('\images\avatar.png')}}" style=" vertical-align: middle; width: 50px; height: 50px;border-radius: 50%;"><br><strong> ({{ auth()->user()->email }})</strong></a>
                                @if(auth()->user()->referrals->count() > 0)
                                    {!! \App\Helpers\UserHelper::treeMemberULHelper(auth()->user()) !!}
                                @else
                                    <ul>
                                        <li><a href="#">You have not added any member</a></li>
                                    </ul>
                                @endif
                            </li>
                        </ul>

                    </div>
                </div>

            </div>

        </div>

        <div class="row">
            <div class="col-md-12">
                <br />
                <br />
                <br />
                <br />
                <br />
            </div>
        </div>

    </div>

@stop

@section('css')
<link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script>

        $(function () {
            // $('#create-user-form').validate();
        })

    </script>
@stop
